from ui import *


class MyWin(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Вход в систему")

        self.ui.pushButton.clicked.connect(self.result)

    def result(self):
        login = self.ui.lineEdit.text()
        password = self.ui.lineEdit_2.text()
        base = [('admin', 'admin'), ('user', 'qwerty'), ('manager', '12345')]
        count = 0
        for i in base:
            if (i[0] == login and i[1] == password):
                msg = QtWidgets.QMessageBox()
                msg.setWindowTitle('Вход')
                msg.setText(
                    "Вы вошли в систему под именем {}".format(login))
                msg.setIcon(msg.Information)
                msg.exec()
                login = self.ui.lineEdit.clear()
                password = self.ui.lineEdit_2.clear()
                break
            count += 1
        if count == len(base):
            msg = QtWidgets.QMessageBox()
            msg.setWindowTitle('Ошибка!')
            msg.setText('Неверно введен логин или пароль')
            msg.setIcon(msg.Critical)
            msg.exec()
            login = self.ui.lineEdit.clear()
            password = self.ui.lineEdit_2.clear()


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    myapp = MyWin()
    myapp.show()
    sys.exit(app.exec_())
