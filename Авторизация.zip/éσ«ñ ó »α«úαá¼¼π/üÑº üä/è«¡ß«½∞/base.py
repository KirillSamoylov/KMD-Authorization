import getpass
import os

base = [('admin', 'admin'), ('user', 'qwerty'), ('manager', '12345')]
count = 0
print("Введите")
login = input("Логин: ")
password = getpass.getpass("Пароль: ")
os.system('CLS')
for i in base:
    if (i[0] == login and i[1] == password):
        print('Вы вошли в систему под именем {}'.format(login))
        input()
        break
    count += 1
if count == len(base):
    print('Вы ввели неверный логин или пароль')
    input()
