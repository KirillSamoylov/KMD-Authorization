from ui import *
from mysql.connector import connect, Error


class MyWin(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Вход в систему")

        self.ui.pushButton.clicked.connect(self.result)

    def result(self):
        login = self.ui.lineEdit.text()
        password = self.ui.lineEdit_2.text()
        try:
            with connect(host="localhost", user="root", database="user") as connection:
                select_query = "SELECT login, password FROM users WHERE login='{}' AND password='{}' LIMIT 1".format(
                    login, password)
                with connection.cursor() as cursor:
                    cursor.execute(select_query)
                    result = cursor.fetchall()
                    if not result:
                        msg = QtWidgets.QMessageBox()
                        msg.setWindowTitle('Ошибка!')
                        msg.setText('Неверно введен логин или пароль')
                        msg.setIcon(msg.Critical)
                        msg.exec()
                        login = self.ui.lineEdit.clear()
                        password = self.ui.lineEdit_2.clear()
                    else:
                        msg = QtWidgets.QMessageBox()
                        msg.setWindowTitle('Вход')
                        msg.setText(
                            "Вы вошли в систему под именем {}".format(login))
                        msg.setIcon(msg.Information)
                        msg.exec()
                        login = self.ui.lineEdit.clear()
                        password = self.ui.lineEdit_2.clear()

        except Error as e:
            msg = QtWidgets.QMessageBox()
            msg.setWindowTitle('Ошибка!')
            msg.setText('Не удалось подключиться к Базе данных!')
            msg.setIcon(msg.Critical)
            msg.exec()
            login = self.ui.lineEdit.clear()
            password = self.ui.lineEdit_2.clear()


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    myapp = MyWin()
    myapp.show()
    sys.exit(app.exec_())
